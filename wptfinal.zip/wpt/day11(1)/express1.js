// const express = require("express");   //using commanjs 
import express from 'express';          //using ECMAscript  need "type"="module" in package.json file

const app = express();
const port = 30000;

app.get("/", function (req, res) {
  res.send("Jay Ganesh jay ram !");
});

app.get("/sum/:slug", (req,res)=>{ 

    //  res.send(res.params.slug * res.params.slug)
    var x=parseInt(req.params.slug) +parseInt( req.params.slug)
    // console.log(x)
    res.send(String(x)) 
})

app.get("/square/:slug", (req,res)=>{ 

    //  res.send(res.params.slug * res.params.slug)
    var x=req.params.slug * req.params.slug
    console.log(req)
    res.send(String(x)) 
})


app.get("/delete", (req,res)=>{ 

   
    res.send("delete request checked...") 
})

app.get("/put", (req,res)=>{ 

   
    res.send("put request checked...") 
})
 
app.post("/post", (req,res)=>{ 

   
    res.send("Hey your post request checked...") 
})
 
app.listen(port, function () {
  console.log(`Example app listening on port ${port}!`);
});