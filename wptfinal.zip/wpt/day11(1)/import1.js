//m-1

// import{writeFile,readFile} from 'fs';
// readFile('demo.txt',(error,data)=>{
// console.log(data);
// });

//m-2

import{writeFile,readFile} from 'fs';
readFile('demo.txt','utf8',(error,data)=>{
console.log(data.toString());
});
