
exports.e=(a)=>
{
    if(a<=1)
    {
          
          return `${a} is not a prime number`;
    }

    for(i=2;i<a;i++)
    {
         if(a%i==0)
         {
            return `${a} is not a prime number`;
        }
    }
    
    return `${a} is a prime number`;
    
}


// exports.e