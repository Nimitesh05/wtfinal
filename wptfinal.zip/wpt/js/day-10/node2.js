// const http=require('http')

// // const module1=require('./module.js')

// const hostname= "127.0.0.1"
// const port=30000


// const server=http.createServer((req,res)=>
// {
//     //  var x=10
//     //  var c=e(x)
//       res.write("hello")

//       res.end()
      
// })

// server.listen(port,()=>
// {
//     console.log(`server is started at https://${hostname}:${port}/ `)
// })


// Load HTTP module
const http = require("http")

const m=require('./module.js')

const hostname = "127.0.0.1";
const port = 8081;


const server = http.createServer(function (req, res) {
  

  var a=2;
  var y=m.e(a)
//    console.log(y)
//   res.write( `${y}`)

  res.write(m.e(a))
  res.end()


});

// Prints a log once the server starts listening
server.listen(port, function () {
  console.log(`Server running at http://${hostname}:${port}/`);
});