// Load HTTP module
const http = require("http");

const hostname = "127.0.0.1";
const port = 8080;

// Create HTTP server
const server = http.createServer(function (req, res) {
  
  // res.writeHead(200,{"Content-type":"text/html"})
  // res.end("<h2>HEllo html h2 tag</h2>")

  // Send the response body "Hello World"
  // res.end("Hello World\n");
  // res.end()

  var a=10;
  var y=40

  res.write("sum is "+( a+y))
  res.end()


});

// Prints a log once the server starts listening
server.listen(port, function () {
  console.log(`Server running at http://${hostname}:${port}/`);
});