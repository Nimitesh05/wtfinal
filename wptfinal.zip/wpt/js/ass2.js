

//we can not find length of object it show undefined
students=[

    {id:1,name:"jay",subject:[{physics:50},{chemistry:40},{maths:90}]},

    {id:2,name:"ayush",subject:[{physics:26},{chemistry:12},{maths:50}]},
    {id:3,name:"karan",subject:[{physics:23},{chemistry:87},{maths:60}]},
    {id:4,name:"yash",subject:[{physics:45},{chemistry:55},{maths:36}]}
]

for(i=0;i<students.length;i++)
{
    avg=0
    sum=0
    cnt=0;
    sum=sum+students[i].subject[cnt++].physics+students[i].subject[cnt++].chemistry+students[i].subject[cnt++].maths

    // len=students[i].subject.length;
    // console.log(len)
    avg=sum/students[i].subject.length

    // avg=sum/len
    console.log(`sum of marks of ${students[i].name} is ${sum}`)
    console.log(`avg of marks of ${students[i].name} is ${avg}`)

    if(sum <150)
        {
            console.log(`${students[i].name} is fail`)
        }
        else
        {
            console.log(`${students[i].name} is pass`)
    
        }


}