let arr=[10,20,30,40]
undefined
arr
(4) [10, 20, 30, 40]
arr.index
undefined
arr.indexOf(20)
1
arr.indexOf(50)
-1
arr.indexOf(30)
2

arr.includes(20)
true
arr.includes(10)
true
arr.includes(100)
false
arr=[1,2,3,4,2,2,1]
(7) [1, 2, 3, 4, 2, 2, 1]
arr.lastIndexOf(2)
5
arr.lastIndexOf(1)
6

arr
(7) [1, 2, 3, 4, 2, 2, 1]
arr.reverse
ƒ reverse() { [native code] }
arr.reverse()
(7) [1, 2, 2, 4, 3, 2, 1]
arr.sort()
(7) [1, 1, 2, 2, 2, 3, 4]
arr.join('#')
'1#1#2#2#2#3#4'
arr.join('.')
'1.1.2.2.2.3.4'
arr.pop()
4
arr.pop()
3
arr.pop()
2
arr
(4) [1, 1, 2, 2]
arr.push(12)
5
arr
(5) [1, 1, 2, 2, 12]
arr.push(6)
6
arr
(6) [1, 1, 2, 2, 12, 6]
arr.pop()
6
arr.pop()
12
arr.pop()
2
arr.pop()
2
arr
(2) [1, 1]
arr.pop()
1
arr
[1]
arr.push(10,20,30)
4
arr
(4) [1, 10, 20, 30]
arr.pop()
30
arr.pop()
20
arr.pop()
10
arr.pop()
1
arr.pop()
undefined
arr
[]
arr.push(10,20,30,40,50)
5
arr
(5) [10, 20, 30, 40, 50]
arr.splice(1,2)
(2) [20, 30]
arr
(3) [10, 40, 50]
arr.splice(1,2,50,60)
(2) [40, 50]
arr
(3) [10, 50, 60]
arr
(3) [10, 50, 60]
arr.push(70,80)
5
arr
(5) [10, 50, 60, 70, 80]
arr.splice(0,2)
(2) [10, 50]
arr
(3) [60, 70, 80]
arr.splice(0,2,10,50)
(2) [60, 70]
arr
(3) [10, 50, 80]
arr.splice(1,1,70)
[50]
arr
(3) [10, 70, 80]
arr.splice(1,1)
[70]
arr
(2) [10, 80]
arr.push(0,7,10,20,30,40,50,60,70)
11
arr
(11) [10, 80, 0, 7, 10, 20, 30, 40, 50, 60, 70]
arr
(11) [10, 80, 0, 7, 10, 20, 30, 40, 50, 60, 70]
arr=[10,80]
(2) [10, 80]
arr
(2) [10, 80]
arr.splice(0,7,10,20,30,40,50,60,70)
(2) [10, 80]
arr
(7) [10, 20, 30, 40, 50, 60, 70]
arr=[10,80]
(2) [10, 80]
arr.splice(1,7,20,30,40,50,60,70,80)
[80]
arr
(8) [10, 20, 30, 40, 50, 60, 70, 80]

//splice concept


arr=[1,2,5,6]
(4) [1, 2, 5, 6]
arr.splice(2,0,3,4)
[]
arr
(6) [1, 2, 3, 4, 5, 6]
arr=[1,2,5,6]
(4) [1, 2, 5, 6]
arr.splice(1,3,3,4)
(3) [2, 5, 6]
arr
(3) [1, 3, 4]