student=[{id:101,name:"Nilesh", marks:46,hobbies:["singing","drwaing"],
    address:{streetno:201,area:"gokul road",city:"Pune"}},

    {id:102,name:"Nimitesh", marks:70,hobbies:["reading","swimming"],
        address:{streetno:10,area:"police nagar",city:"Nagpur"}}
]

max=student[0]

for(i=0;i<student.length;i++)
{
    if(max.marks<student[i].marks)
    {
        max.marks=student[i].marks
    }
}

console.log(max)