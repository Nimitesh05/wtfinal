//we can not find length of object it show undefined
students=[

    {id:1,name:"jay",subject:[50,40,90]},
    {id:2,name:"ayush",subject:[26,12,50]},
    {id:3,name:"karan",subject:[23,87,60]},
    {id:4,name:"yash",subject:[45,55,36]}
]

for(i=0;i<students.length;i++)
{
    avg=0
    sum=0
    for(j=0;j<students[i].subject.length;j++)
    {

        sum=sum+students[i].subject[j]
    }

    // len=students[i].subject.length;
    // console.log(len)
    avg=sum/students[i].subject.length

    // avg=sum/len
    console.log(`sum of marks of ${students[i].name} is ${sum}`)
    console.log(`avg of marks of ${students[i].name} is ${avg}`)

    if(sum <150)
        {
            console.log(`${students[i].name} is fail`)
        }
        else
        {
            console.log(`${students[i].name} is pass`)
    
        }

}