a={id:1,name:"jas"}
b={age:12}
c={a,b}
c={...a,...b} // spread operator {...}
console.log(c)